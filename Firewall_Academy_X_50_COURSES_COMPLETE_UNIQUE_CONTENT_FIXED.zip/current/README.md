# Firewall Academy X — Browser AI Coach

This is the browser-only edition of Firewall Academy X. It runs with VS Code Live Server in Chrome or Microsoft Edge and does not require Node.js or MongoDB.

## AI Coach modes

### 1. Smart Local Firewall Coach
Works immediately without an API key. It provides intent-aware educational answers for common networking, firewall and cybersecurity topics, greetings, follow-up examples, comparisons, exam questions, rule reviews, service ports and many related concepts. Chat history is kept in this browser.

### 2. Gemini Live AI
Click **Gemini Key** and enter your own Gemini API key. The key is stored only in this browser's local storage. With a valid key and internet access, the Coach sends the recent conversation to Gemini and can answer open-ended questions much more broadly than the offline knowledge base.

> Browser-only Gemini means the API key is necessarily available to the browser. Do not use this mode with a key you cannot safely expose to the user. For production/shared deployments, use a server-side proxy/backend instead.

## Run

1. Open the project in VS Code.
2. Right-click `index.html`.
3. Choose **Open with Live Server**.
4. Use Chrome or Microsoft Edge.

No `npm install`, Node.js or MongoDB is required.

## Notes

A browser cannot directly inspect or change the operating system firewall. Device Firewall checks therefore use browser-safe environment checks and explain the local OS verification commands instead of pretending to know the OS firewall state.


## 50-course content validation
Every course has a separate rich content object keyed by course ID, including a topic-specific overview, objectives, prerequisite, seven lesson modules, practical activity, case study, summary, takeaways and five final-assessment questions. Lesson rendering reads the selected course ID so content cannot silently switch to another course.
